# AdultFilmDatabase.bundle

Plex metadata agent for fetching metadata from AdultFilmDatabase and IAFD
20201225 - 	Actor thumbnails source from IAFD
			Filenames must be named according to this format: (Studio) - Title (Year).ext
			Agent attempts to match according to the filename, and does not approximate or suggest matches
			if filename pattern is not met, the agent will abort matching.
			background art is set to the back cover of the dvd.
